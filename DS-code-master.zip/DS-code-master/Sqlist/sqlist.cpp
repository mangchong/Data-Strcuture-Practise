#include <iostream>
using namespace std;
#define maxsize 100
typedef struct
{
  int data[maxsize];
  int length;
} Sqlist;