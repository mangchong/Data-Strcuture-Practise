#include <iostream>
using namespace std;
#define maxsize 50
typedef struct
{
  int data[maxsize];
  int length;
} Sqlist;
